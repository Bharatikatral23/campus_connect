/* =========================================================
   CampusConnect - FRONT-END (HTML + CSS + JavaScript)
   Talks to the Node.js back-end through fetch() API calls.
   ========================================================= */

/* ---------- Helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const today = () => new Date().toISOString().slice(0, 10);
const fmtDate = (d) => new Date(d + "T00:00:00").toLocaleDateString(undefined, { weekday: "short", year: "numeric", month: "short", day: "numeric" });

function toast(msg, isError = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast show" + (isError ? " error" : "");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.className = "toast"), 2500);
}

/* ---------- API helper (front-end -> back-end) ---------- */
let token = localStorage.getItem("cc_token");

async function api(path, method = "GET", body) {
  const res = await fetch("/api" + path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && token) logout();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

/* ---------- State ---------- */
const state = { user: null, tab: "dashboard", notes: [], noteSearch: "", noteSubject: "", noteSem: "" };
const isAdmin = () => state.user?.role === "admin";

/* ---------- Auth ---------- */
async function signup(form) {
  const f = Object.fromEntries(new FormData(form));
  await api("/signup", "POST", f);
  toast("Account created! Please login.");
  switchAuthTab("login");
  form.reset();
}

async function login(form) {
  const f = Object.fromEntries(new FormData(form));
  const data = await api("/login", "POST", f);
  token = data.token;
  localStorage.setItem("cc_token", token);
  await startApp();
}

function logout() {
  token = null;
  localStorage.removeItem("cc_token");
  state.user = null;
  $("#app-view").classList.add("hidden");
  $("#auth-view").classList.remove("hidden");
}

function switchAuthTab(which) {
  $$("[data-auth]").forEach((b) => b.classList.toggle("active", b.dataset.auth === which));
  $("#login-form").classList.toggle("hidden", which !== "login");
  $("#signup-form").classList.toggle("hidden", which !== "signup");
}

async function startApp() {
  try {
    state.user = (await api("/me")).user;
  } catch {
    return logout();
  }
  $("#auth-view").classList.add("hidden");
  $("#app-view").classList.remove("hidden");
  $("#user-label").innerHTML = `${esc(state.user.name)} <span class="badge">${state.user.role}</span>`;
  state.tab = "dashboard";
  render();
}

/* ---------- Navigation & rendering ---------- */
async function render() {
  const tabs = [["dashboard", "Dashboard"], ["notes", "Notes"], ["events", "Events"], ["rooms", "Study Rooms"]];
  if (isAdmin()) tabs.push(["admin", "Admin"]);
  $("#nav").innerHTML = tabs
    .map(([id, label]) => `<button data-tab="${id}" class="${state.tab === id ? "active" : ""}">${label}</button>`)
    .join("");

  const views = { dashboard: viewDashboard, notes: viewNotes, events: viewEvents, rooms: viewRooms, admin: viewAdmin };
  const tab = state.tab;
  try {
    const html = await views[tab]();
    if (tab === state.tab) $("#content").innerHTML = html;
  } catch (err) {
    toast(err.message, true);
  }
}

/* ---------- Dashboard ---------- */
async function viewDashboard() {
  const d = await api("/dashboard");
  return `
    <h2 class="page-title">Welcome back, ${esc(state.user.name)} 👋</h2>
    <div class="grid stats">
      <div class="card stat"><div class="num">${d.notes}</div><div class="lbl">Shared Notes</div></div>
      <div class="card stat"><div class="num">${d.events}</div><div class="lbl">Events</div></div>
      <div class="card stat"><div class="num">${d.myRsvps}</div><div class="lbl">My RSVPs</div></div>
      <div class="card stat"><div class="num">${d.myBookings}</div><div class="lbl">My Bookings</div></div>
    </div>
    <div class="grid cols-2">
      <div class="card">
        <h3>📅 Upcoming Events</h3>
        ${d.upcoming.length
          ? d.upcoming.map((e) => `<p><strong>${esc(e.title)}</strong><br><span class="muted">${fmtDate(e.date)} · ${esc(e.time)} · ${esc(e.location)}</span></p><br>`).join("")
          : `<div class="empty">No upcoming events</div>`}
      </div>
      <div class="card">
        <h3>🏫 My Room Bookings</h3>
        ${d.recentBookings.length
          ? d.recentBookings.map((b) => `<p><strong>${esc(b.room)}</strong><br><span class="muted">${fmtDate(b.date)} · ${b.start} - ${b.end}</span></p><br>`).join("")
          : `<div class="empty">No bookings yet</div>`}
      </div>
    </div>`;
}

/* ---------- Notes ---------- */
function notesListHTML() {
  const q = state.noteSearch.toLowerCase();
  const list = state.notes.filter(
    (n) =>
      (!q || n.title.toLowerCase().includes(q) || n.description.toLowerCase().includes(q)) &&
      (!state.noteSubject || n.subject === state.noteSubject) &&
      (!state.noteSem || n.semester === state.noteSem)
  );
  if (!list.length) return `<div class="empty" style="grid-column:1/-1">No notes found</div>`;
  return list
    .map(
      (n) => `
    <div class="item">
      <span class="badge">${esc(n.subject)}</span><span class="badge">Sem ${esc(n.semester)}</span>
      ${n.status === "pending" ? `<span class="badge pending">Pending</span>` : ""}
      <h4>${esc(n.title)}</h4>
      <p>${esc(n.description)}</p>
      <p>By ${esc(n.userName)} · ${esc(n.date)}</p>
      <div class="actions">
        ${n.hasFile ? `<button class="btn small" data-action="download-note" data-id="${n.id}">⬇ Download</button>` : ""}
        ${n.userId === state.user.id || isAdmin() ? `<button class="btn small danger" data-action="delete-note" data-id="${n.id}">Delete</button>` : ""}
      </div>
    </div>`
    )
    .join("");
}

async function viewNotes() {
  state.notes = await api("/notes");
  const subjects = [...new Set(state.notes.map((n) => n.subject))].sort();
  return `
    <h2 class="page-title">📚 Notes &amp; Study Materials</h2>
    <div class="card">
      <h3>Share a note</h3>
      <form data-form="note">
        <div class="form-row">
          <input name="title" placeholder="Title" required />
          <input name="subject" placeholder="Subject (e.g. Maths)" required />
          <select name="semester" required>
            <option value="">Semester</option>
            ${[1, 2, 3, 4, 5, 6, 7, 8].map((s) => `<option value="${s}">Semester ${s}</option>`).join("")}
          </select>
        </div>
        <textarea name="description" rows="2" placeholder="Short description" required></textarea>
        <label>Attach file (optional, max 1.5 MB)</label>
        <input type="file" name="file" />
        <button class="btn" type="submit">Upload Note</button>
        ${isAdmin() ? "" : `<p class="hint">Student uploads are reviewed by an admin before they appear publicly.</p>`}
      </form>
    </div>
    <div class="toolbar">
      <input id="note-search" placeholder="🔍 Search notes..." value="${esc(state.noteSearch)}" />
      <select id="note-subject">
        <option value="">All subjects</option>
        ${subjects.map((s) => `<option ${state.noteSubject === s ? "selected" : ""}>${esc(s)}</option>`).join("")}
      </select>
      <select id="note-sem">
        <option value="">All semesters</option>
        ${[1, 2, 3, 4, 5, 6, 7, 8].map((s) => `<option value="${s}" ${state.noteSem === String(s) ? "selected" : ""}>Semester ${s}</option>`).join("")}
      </select>
    </div>
    <div class="grid cols-3" id="notes-list">${notesListHTML()}</div>`;
}

async function addNote(form) {
  const f = Object.fromEntries(new FormData(form));
  const file = form.elements.file.files[0];
  delete f.file;
  if (file) {
    if (file.size > 1.5 * 1024 * 1024) throw new Error("File too large (max 1.5 MB)");
    f.fileName = file.name;
    f.fileData = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Could not read file"));
      reader.readAsDataURL(file);
    });
  }
  const r = await api("/notes", "POST", f);
  toast(r.message);
  render();
}

async function downloadNote(id) {
  const f = await api(`/notes/${id}/file`);
  const a = document.createElement("a");
  a.href = f.fileData;
  a.download = f.fileName || "note";
  a.click();
}

async function deleteNote(id) {
  if (!confirm("Delete this note?")) return;
  toast((await api(`/notes/${id}`, "DELETE")).message);
  render();
}

/* ---------- Events ---------- */
async function viewEvents() {
  const events = await api("/events");
  return `
    <h2 class="page-title">📅 Campus Events</h2>
    ${isAdmin() ? `<div class="card">
      <h3>Create an event</h3>
      <form data-form="event">
        <div class="form-row">
          <input name="title" placeholder="Event title" required />
          <input name="location" placeholder="Location" required />
          <input type="date" name="date" min="${today()}" required />
          <input type="time" name="time" required />
          <input type="number" name="capacity" min="1" placeholder="Capacity" required />
        </div>
        <textarea name="description" rows="2" placeholder="Description" required></textarea>
        <button class="btn" type="submit">Post Event</button>
      </form>
    </div>` : ""}
    <div class="grid cols-2">
      ${events.length ? events.map((e) => {
        const full = e.count >= e.capacity;
        const past = e.date < today();
        return `
        <div class="item">
          <span class="badge ${past ? "pending" : "ok"}">${past ? "Past" : "Upcoming"}</span>
          <h4>${esc(e.title)}</h4>
          <p>${fmtDate(e.date)} · ${esc(e.time)} · 📍 ${esc(e.location)}</p>
          <p>${esc(e.description)}</p>
          <p><strong>${e.count}/${e.capacity}</strong> attending</p>
          ${isAdmin() && e.attendees.length ? `<p>Attendees: ${e.attendees.map(esc).join(", ")}</p>` : ""}
          <div class="actions">
            ${!isAdmin()
              ? `<button class="btn small ${e.going ? "outline" : ""}" data-action="rsvp" data-id="${e.id}" ${!e.going && (full || past) ? "disabled" : ""}>
                  ${e.going ? "Cancel RSVP" : full ? "Event Full" : "RSVP"}
                </button>`
              : `<button class="btn small danger" data-action="delete-event" data-id="${e.id}">Delete</button>`}
          </div>
        </div>`;
      }).join("") : `<div class="empty" style="grid-column:1/-1">No events posted yet</div>`}
    </div>`;
}

async function addEvent(form) {
  const r = await api("/events", "POST", Object.fromEntries(new FormData(form)));
  toast(r.message);
  render();
}

async function toggleRsvp(id) {
  toast((await api(`/events/${id}/rsvp`, "POST")).message);
  render();
}

async function deleteEvent(id) {
  if (!confirm("Delete this event?")) return;
  toast((await api(`/events/${id}`, "DELETE")).message);
  render();
}

/* ---------- Study Rooms ---------- */
async function viewRooms() {
  const [rooms, list] = await Promise.all([api("/rooms"), api("/bookings")]);
  return `
    <h2 class="page-title">🏫 Study Room Booking</h2>
    <div class="card">
      <h3>Book a room</h3>
      <form data-form="booking">
        <div class="form-row">
          <select name="room" required>
            <option value="">Select room</option>
            ${rooms.map((r) => `<option>${esc(r)}</option>`).join("")}
          </select>
          <input type="date" name="date" min="${today()}" required />
          <input type="time" name="start" required />
          <input type="time" name="end" required />
        </div>
        <button class="btn" type="submit">Book Room</button>
      </form>
    </div>
    <div class="card">
      <h3>${isAdmin() ? "All bookings" : "My bookings"}</h3>
      ${list.length ? `<div class="table-wrap"><table>
        <tr><th>Room</th><th>Date</th><th>Time</th>${isAdmin() ? "<th>Booked by</th>" : ""}<th></th></tr>
        ${list.map((b) => `<tr>
          <td>${esc(b.room)}</td><td>${fmtDate(b.date)}</td><td>${b.start} - ${b.end}</td>
          ${isAdmin() ? `<td>${esc(b.userName)}</td>` : ""}
          <td><button class="btn small danger" data-action="cancel-booking" data-id="${b.id}">Cancel</button></td>
        </tr>`).join("")}
      </table></div>` : `<div class="empty">No bookings yet</div>`}
    </div>`;
}

async function addBooking(form) {
  const r = await api("/bookings", "POST", Object.fromEntries(new FormData(form)));
  toast(r.message);
  render();
}

async function cancelBooking(id) {
  toast((await api(`/bookings/${id}`, "DELETE")).message);
  render();
}

/* ---------- Admin ---------- */
async function viewAdmin() {
  const [s, users, notes] = await Promise.all([api("/admin/stats"), api("/admin/users"), api("/notes")]);
  const pending = notes.filter((n) => n.status === "pending");
  return `
    <h2 class="page-title">🛠 Admin Dashboard</h2>
    <div class="grid stats">
      <div class="card stat"><div class="num">${s.users}</div><div class="lbl">Users</div></div>
      <div class="card stat"><div class="num">${s.notes}</div><div class="lbl">Total Notes</div></div>
      <div class="card stat"><div class="num">${s.pending}</div><div class="lbl">Pending Approval</div></div>
      <div class="card stat"><div class="num">${s.events}</div><div class="lbl">Events</div></div>
      <div class="card stat"><div class="num">${s.bookings}</div><div class="lbl">Bookings</div></div>
    </div>
    <div class="card">
      <h3>Pending notes</h3>
      ${pending.length ? `<div class="table-wrap"><table>
        <tr><th>Title</th><th>Subject</th><th>By</th><th></th></tr>
        ${pending.map((n) => `<tr>
          <td>${esc(n.title)}</td><td>${esc(n.subject)}</td><td>${esc(n.userName)}</td>
          <td>
            <button class="btn small success" data-action="approve-note" data-id="${n.id}">Approve</button>
            <button class="btn small danger" data-action="delete-note" data-id="${n.id}">Reject</button>
          </td>
        </tr>`).join("")}
      </table></div>` : `<div class="empty">Nothing waiting for approval 🎉</div>`}
    </div>
    <div class="card">
      <h3>Manage users</h3>
      <div class="table-wrap"><table>
        <tr><th>Name</th><th>Email</th><th>Role</th><th></th></tr>
        ${users.map((u) => `<tr>
          <td>${esc(u.name)}</td><td>${esc(u.email)}</td><td><span class="badge">${u.role}</span></td>
          <td>${u.id === state.user.id ? `<span class="muted">You</span>` : `<button class="btn small danger" data-action="delete-user" data-id="${u.id}">Remove</button>`}</td>
        </tr>`).join("")}
      </table></div>
    </div>`;
}

async function approveNote(id) {
  toast((await api(`/notes/${id}/approve`, "POST")).message);
  render();
}

async function deleteUser(id) {
  if (!confirm("Remove this user and their content?")) return;
  toast((await api(`/admin/users/${id}`, "DELETE")).message);
  render();
}

/* ---------- Event listeners (delegation) ---------- */
async function safely(fn) {
  try {
    await fn();
  } catch (err) {
    toast(err.message, true);
  }
}

document.addEventListener("click", (e) => {
  const authBtn = e.target.closest("[data-auth]");
  if (authBtn) return switchAuthTab(authBtn.dataset.auth);

  const tabBtn = e.target.closest("[data-tab]");
  if (tabBtn) {
    state.tab = tabBtn.dataset.tab;
    return render();
  }

  const btn = e.target.closest("[data-action]");
  if (!btn) return;
  const { action, id } = btn.dataset;
  const actions = {
    logout,
    "download-note": () => downloadNote(id),
    "delete-note": () => deleteNote(id),
    "approve-note": () => approveNote(id),
    rsvp: () => toggleRsvp(id),
    "delete-event": () => deleteEvent(id),
    "cancel-booking": () => cancelBooking(id),
    "delete-user": () => deleteUser(id),
  };
  if (actions[action]) safely(actions[action]);
});

document.addEventListener("submit", (e) => {
  const form = e.target.closest("[data-form]");
  if (!form) return;
  e.preventDefault();
  const handlers = { login, signup, note: addNote, event: addEvent, booking: addBooking };
  if (handlers[form.dataset.form]) safely(() => handlers[form.dataset.form](form));
});

document.addEventListener("input", (e) => {
  if (e.target.id === "note-search") {
    state.noteSearch = e.target.value;
    $("#notes-list").innerHTML = notesListHTML();
  }
});

document.addEventListener("change", (e) => {
  if (e.target.id === "note-subject") { state.noteSubject = e.target.value; $("#notes-list").innerHTML = notesListHTML(); }
  if (e.target.id === "note-sem") { state.noteSem = e.target.value; $("#notes-list").innerHTML = notesListHTML(); }
});

/* ---------- Live background picker (CSS --app-bg is the default) ---------- */
$("#bg-color").addEventListener("input", (e) => {
  document.body.style.background = e.target.value;
  document.body.style.backgroundAttachment = "fixed";
});

/* ---------- Init ---------- */
if (token) startApp();
